#include <iostream>
using namespace std;

int main()
{
  string nombre;

  cout << "Nombre del Cliente:";
  cin >> nombre;

  cout << "Hola " << nombre << " bienvenido al mundo c++!!";

}